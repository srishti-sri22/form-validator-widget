// src/components/ChangeForm.tsx (or wherever your DynamicForm lives)
import React, { useEffect } from "react";
import { useFormSubmission } from "../hooks/useFormSubmission";
import { useFormValidator } from "../hooks/useFormValidator";
import { generateThemeVariables, getTheme } from "../utils/themes";
import "../styles/FormValidationWidget.css";

import type {
  CustomizationOptions,
  FieldConfig,
  FormTheme,
  ThemeName,
} from "../utils/types";
import FormField from "./FormField";


interface FormProps {
  fields: FieldConfig[];
  onSubmit: (values: Record<string, unknown>) => void | Promise<void>;
  validationMode?: "onChange" | "onBlur" | "onSubmit";
  customization?: CustomizationOptions;
  submitButtonText?: string;
  resetButtonText?: string;
  showResetButton?: boolean;
  disabled?: boolean;
  className?: string;
  submitThrottleMs?: number;
  theme?: ThemeName | FormTheme;
}

const DynamicForm: React.FC<FormProps> = ({
  fields,
  onSubmit,
  validationMode = "onBlur",
  customization = {},
  submitButtonText = "Submit",
  resetButtonText = "Reset",
  showResetButton = true,
  disabled = false,
  className,
  submitThrottleMs = 1200,
  theme = "modern_themes", // correct key from your ThemeName union
}) => {
  const {
    formState,
    setFieldValue,
    setFieldTouched,
    validateFormFields,
    resetForm,
    setFormState,
  } = useFormValidator(fields, validationMode);

  const {
    handleSubmit,
    isSubmitting,
    isThrottled,
    submitError,
    setSubmitError,
  } = useFormSubmission(onSubmit, validateFormFields, formState.values, submitThrottleMs, setFormState);

  // clear submit error when there are no validation errors
  useEffect(() => {
    const hasErrors = Object.values(formState.errors).some(Boolean);
    if (!hasErrors && submitError) {
      setSubmitError(null);
    }
  }, [formState.errors, submitError, setSubmitError]);

  const selectedTheme = getTheme(theme);
  const themeVariables = generateThemeVariables(selectedTheme);

  const rootClass = ["fvw-container", className, customization.containerClass].filter(Boolean).join(" ");
  const formClass = ["fvw-form", customization.formClass].filter(Boolean).join(" ");
  const submitBtnClass = ["fvw-button", customization.buttonClass, isSubmitting ? "fvw-loading" : ""].filter(Boolean).join(" ");
  const resetBtnClass = ["fvw-button", "fvw-secondary", customization.buttonClass].filter(Boolean).join(" ");

  return (
    <div className="fvw-wrapper" style={themeVariables as React.CSSProperties}>
      <form onSubmit={handleSubmit} className="fvw-form" noValidate>
  <div className="fvw-root">
    {fields.map((field) => (
      <FormField
        key={field.name}
        field={field}
        value={formState.values[field.name]}
        error={formState.errors[field.name] || ""}
        touched={!!formState.touched[field.name]}
        disabled={disabled || !!field.disabled}
        onChange={(name, value) => setFieldValue(name, value)}
        onBlur={(name) => setFieldTouched(name)}
        showAnimation={true}
      />
    ))}

    {submitError && (
      <div role="alert" className="fvw-submit-error">
        ⚠ {submitError}
      </div>
    )}

    <div className="fvw-actions">
      <button
        type="submit"
        disabled={disabled || isSubmitting}
        className="fvw-btn-submit"
      >
        {isSubmitting ? "Submitting..." : submitButtonText}
      </button>

      {showResetButton && (
        <button
          type="button"
          onClick={resetForm}
          disabled={disabled || isSubmitting}
          className="fvw-btn-reset"
        >
          {resetButtonText}
        </button>
      )}
    </div>
  </div>
</form>

    </div>
  );
};

export default DynamicForm;
